
package textEditor;

import javax.swing.JFrame;

public class TextEditor extends JFrame{

    public static void main(String[] args) {
        NotepadGUI obj = new NotepadGUI();
        obj.setBounds(0, 0, 900, 700);
        obj.setTitle("Notepad");
        obj.setVisible(true);
        obj.setResizable(false);
        obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
