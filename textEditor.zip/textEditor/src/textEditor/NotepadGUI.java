
package textEditor;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.TextArea;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.font.TextAttribute;
import java.awt.print.PageFormat;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.AttributedString;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListCellRenderer;
import static javax.swing.GroupLayout.Alignment.CENTER;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Document;
import javax.swing.text.Highlighter;
import javax.swing.text.JTextComponent;
import jdk.nashorn.tools.Shell;

public class NotepadGUI extends javax.swing.JFrame {

    String filename;
    Clipboard clipboard = getToolkit().getSystemClipboard();

    public NotepadGUI() {
        this.highlighter = new myHighlighter(Color.yellow);
        filename="";
        initComponents();
        this.sizeUpDown.setValue(12);
        GraphicsEnvironment graphEnviron = 
        GraphicsEnvironment.getLocalGraphicsEnvironment();
        Font[] allFonts = graphEnviron.getAllFonts();
        for(int i=0; i<allFonts.length; i++)
        {
            String font = allFonts[i].getFontName();
            fontsList.addItem(font);
            
        }
        fontsList.setSelectedItem("Arial");
        
        String timeStamp = new SimpleDateFormat("dd-MM-yyyy EEE ").format(Calendar.getInstance().getTime());
        dateLabel.setText(timeStamp);
        textArea.setLineWrap(true);
    
        

        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        fontsList = new javax.swing.JComboBox<>();
        sizeUpDown = new javax.swing.JSpinner();
        fontColor = new javax.swing.JButton();
        textAreaColor = new javax.swing.JButton();
        boldText = new javax.swing.JToggleButton();
        italicText = new javax.swing.JToggleButton();
        searchField = new javax.swing.JTextField();
        searchText = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        wordsLabel = new javax.swing.JLabel();
        wordsCount = new javax.swing.JLabel();
        charCountLabel = new javax.swing.JLabel();
        charCount = new javax.swing.JLabel();
        dateLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        textArea = new javax.swing.JTextArea();
        jMenuBar1 = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        newFile = new javax.swing.JMenuItem();
        openFile = new javax.swing.JMenuItem();
        saveFile = new javax.swing.JMenuItem();
        saveFileAs = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        printFile = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        exitProgram = new javax.swing.JMenuItem();
        editMenu = new javax.swing.JMenu();
        backStep = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        copyText = new javax.swing.JMenuItem();
        cutText = new javax.swing.JMenuItem();
        pasteText = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(900, 700));

        fontsList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fontsListActionPerformed(evt);
            }
        });

        sizeUpDown.setModel(new javax.swing.SpinnerNumberModel(12, 1, 150, 1));
        sizeUpDown.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sizeUpDownStateChanged(evt);
            }
        });

        fontColor.setText("kolor czcionki");
        fontColor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fontColorActionPerformed(evt);
            }
        });

        textAreaColor.setText("kolor tła");
        textAreaColor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textAreaColorActionPerformed(evt);
            }
        });

        boldText.setText("B");
        boldText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boldTextActionPerformed(evt);
            }
        });

        italicText.setText("I");
        italicText.setToolTipText("");
        italicText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                italicTextActionPerformed(evt);
            }
        });

        searchText.setText("Szukaj");
        searchText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchTextActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 708, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(searchText))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(fontsList, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(boldText)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(italicText, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fontColor)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(textAreaColor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(sizeUpDown))))
                .addContainerGap(156, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchText))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fontsList, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sizeUpDown, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boldText)
                    .addComponent(italicText)
                    .addComponent(fontColor)
                    .addComponent(textAreaColor))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        fontsList.getAccessibleContext().setAccessibleName("fonts");
        fontColor.getAccessibleContext().setAccessibleName("colorText");
        textAreaColor.getAccessibleContext().setAccessibleName("colorBackground");
        boldText.getAccessibleContext().setAccessibleName("fat");
        italicText.getAccessibleContext().setAccessibleName("underline");

        wordsLabel.setText("Ilość słów: ");

        charCountLabel.setText("Ilość znaków: ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(wordsLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(wordsCount, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(charCountLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(charCount)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(dateLabel)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(wordsLabel)
                    .addComponent(wordsCount)
                    .addComponent(charCountLabel)
                    .addComponent(charCount)
                    .addComponent(dateLabel))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        textArea.setColumns(20);
        textArea.setRows(5);
        textArea.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                textAreaKeyTyped(evt);
            }
        });
        jScrollPane1.setViewportView(textArea);

        fileMenu.setText("Plik");

        newFile.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        newFile.setText("Nowy");
        newFile.setActionCommand("newFile");
        newFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newFileActionPerformed(evt);
            }
        });
        fileMenu.add(newFile);
        newFile.getAccessibleContext().setAccessibleName("newFile");

        openFile.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        openFile.setText("Otwórz");
        openFile.setActionCommand("Open");
        openFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openFileActionPerformed(evt);
            }
        });
        fileMenu.add(openFile);
        openFile.getAccessibleContext().setAccessibleName("Open");

        saveFile.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        saveFile.setText("Zapisz");
        saveFile.setActionCommand("saveFile");
        saveFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveFileActionPerformed(evt);
            }
        });
        fileMenu.add(saveFile);
        saveFile.getAccessibleContext().setAccessibleName("saveFile");

        saveFileAs.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        saveFileAs.setText("Zapisz jako...");
        saveFileAs.setActionCommand("saveAs");
        saveFileAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveFileAsActionPerformed(evt);
            }
        });
        fileMenu.add(saveFileAs);
        saveFileAs.getAccessibleContext().setAccessibleName("saveAs");

        fileMenu.add(jSeparator2);

        printFile.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_P, java.awt.event.InputEvent.CTRL_MASK));
        printFile.setText("Drukuj...");
        printFile.setActionCommand("printFile");
        printFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printFileActionPerformed(evt);
            }
        });
        fileMenu.add(printFile);
        printFile.getAccessibleContext().setAccessibleName("printFile");

        fileMenu.add(jSeparator3);

        exitProgram.setText("Zakończ");
        exitProgram.setActionCommand("quit");
        exitProgram.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitProgramActionPerformed(evt);
            }
        });
        fileMenu.add(exitProgram);
        exitProgram.getAccessibleContext().setAccessibleName("quit");

        jMenuBar1.add(fileMenu);

        editMenu.setText("Edytuj");

        backStep.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Z, java.awt.event.InputEvent.CTRL_MASK));
        backStep.setText("Cofnij");
        backStep.setActionCommand("backStep");
        editMenu.add(backStep);
        backStep.getAccessibleContext().setAccessibleName("backStep");

        editMenu.add(jSeparator1);

        copyText.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        copyText.setText("Kopiuj");
        copyText.setActionCommand("copyText");
        copyText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copyTextActionPerformed(evt);
            }
        });
        editMenu.add(copyText);
        copyText.getAccessibleContext().setAccessibleName("copyText");

        cutText.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_MASK));
        cutText.setText("Wytnij");
        cutText.setActionCommand("cutText");
        cutText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutTextActionPerformed(evt);
            }
        });
        editMenu.add(cutText);
        cutText.getAccessibleContext().setAccessibleName("cutText");

        pasteText.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, java.awt.event.InputEvent.CTRL_MASK));
        pasteText.setText("Wklej");
        pasteText.setActionCommand("pasteText");
        pasteText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasteTextActionPerformed(evt);
            }
        });
        editMenu.add(pasteText);
        pasteText.getAccessibleContext().setAccessibleName("pasteText");

        jMenuBar1.add(editMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(26, 26, 26))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 887, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 372, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchTextActionPerformed
        searchTextArea(textArea, searchField.getText());
    }//GEN-LAST:event_searchTextActionPerformed
    
    class myHighlighter extends DefaultHighlighter.DefaultHighlightPainter{
        public myHighlighter(Color color)
        {
            super(color);
        }
    }
    DefaultHighlighter.HighlightPainter highlighter = new myHighlighter(Color.yellow);
    
    
    public void removeHighLight(JTextComponent textComp){
        Highlighter removeHighlighter = textComp.getHighlighter();
        Highlighter.Highlight[] remove = removeHighlighter.getHighlights();
        
        for(int i =0; i<remove.length; i++){
            
            if(remove[i].getPainter() instanceof myHighlighter){
                removeHighlighter.removeHighlight(remove[i]);
            }
        }
    }
    
    public void searchTextArea(JTextComponent textComp, String textString){
        removeHighLight(textComp);
        try{
            Highlighter highlight = textComp.getHighlighter();
            Document doc = textComp.getDocument();
            String text = doc.getText(0, doc.getLength());
            
            int pos = 0;
            if(textArea.getBackground().equals(Color.yellow) || textArea.getForeground().equals(Color.yellow))
            {
                highlighter = new myHighlighter(Color.red);
            }
            while((pos = text.toUpperCase().indexOf(textString.toUpperCase(),pos))>= 0){
                highlight.addHighlight(pos, pos+textString.length(), highlighter);
                pos += textString.length();
            }
        }catch(Exception e){
            
        }
    }
    
    private void newFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newFileActionPerformed
        // TODO add your handling code here:
        textArea.setText("");
        setTitle(filename);
    }//GEN-LAST:event_newFileActionPerformed

    private void openFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openFileActionPerformed
        FileDialog fileDialog = new FileDialog(NotepadGUI.this, "Otórz plik",FileDialog.LOAD);
        fileDialog.setVisible(true);
        
        if(fileDialog.getFile() != null)
        {
            filename = fileDialog.getDirectory() + fileDialog.getFile();
            setTitle(filename);
        }
        try{
            BufferedReader reader = new BufferedReader(new FileReader(filename));
            StringBuilder sb = new StringBuilder();
            
            String line = null;
            
            while((line = reader.readLine())!=null)
            {
                sb.append(line + "\n");
                textArea.setText(sb.toString());
            }
            reader.close();
        }
        catch(IOException e){
            System.out.println("Nie znaleziono pliku");
        }
    }//GEN-LAST:event_openFileActionPerformed

    private void saveFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveFileActionPerformed
        
        if(filename.equals(""))
        {
            FileDialog fileDialog = new FileDialog(NotepadGUI.this, "Zapisz plik",FileDialog.SAVE);
            fileDialog.setVisible(true);
        
            if(fileDialog.getFile() != null)
            {
                filename = fileDialog.getDirectory() + fileDialog.getFile() +".txt";
                setTitle(filename);
            }
            try{
                FileWriter fileWriter = new FileWriter(filename);
                fileWriter.write(textArea.getText());
                setTitle(filename);
                fileWriter.close();
            }
            catch(IOException e){
                System.out.println("Nie znaleziono pliku");
            }
        }
        else
        {
            try
            {
                //filename=filename+".txt";
                FileWriter fileWriter = new FileWriter(filename, true);
                fileWriter.write(textArea.getText());
                fileWriter.close();
            } catch (IOException e) {
                //exception handling left as an exercise for the reader
            }
        }
        
        
    }//GEN-LAST:event_saveFileActionPerformed

    private void saveFileAsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveFileAsActionPerformed
        FileDialog fileDialog = new FileDialog(NotepadGUI.this, "Zapisz plik",FileDialog.SAVE);
            fileDialog.setVisible(true);
        
            if(fileDialog.getFile() != null)
            {
                filename = fileDialog.getDirectory() + fileDialog.getFile()+".txt";
                setTitle(filename);
            }
            try{
                FileWriter fileWriter = new FileWriter(filename);
                fileWriter.write(textArea.getText());
                setTitle(filename);
                fileWriter.close();
            }
            catch(IOException e){
                System.out.println("Nie znaleziono pliku");
            }
    }//GEN-LAST:event_saveFileAsActionPerformed

    private void printFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printFileActionPerformed
        PrinterJob printerJob = PrinterJob.getPrinterJob();
        PageFormat pf = printerJob.pageDialog(printerJob.defaultPage());

        if (printerJob.printDialog()) {
        try {printerJob.print();}
        catch (PrinterException exc) {
            System.out.println(exc);
         }
     } 
    }//GEN-LAST:event_printFileActionPerformed

    private void exitProgramActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitProgramActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitProgramActionPerformed

    private void cutTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutTextActionPerformed
        String cutString = textArea.getSelectedText();
        StringSelection cutSelection = new StringSelection(cutString);
        clipboard.setContents(cutSelection, cutSelection);
        textArea.replaceRange("", textArea.getSelectionStart(), textArea.getSelectionEnd());
    }//GEN-LAST:event_cutTextActionPerformed

    private void pasteTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasteTextActionPerformed
        try{
            Transferable pasteText = clipboard.getContents(NotepadGUI.this);
            String sel = (String) pasteText.getTransferData(DataFlavor.stringFlavor);
            textArea.replaceRange(sel, textArea.getSelectionStart(), textArea.getSelectionEnd());
        }
        catch(Exception e){
            System.out.println("Nie zadziałało");
        }
    }//GEN-LAST:event_pasteTextActionPerformed

    private void copyTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyTextActionPerformed
        String cpyText = textArea.getSelectedText();
        StringSelection copySelection = new StringSelection(cpyText);
        clipboard.setContents(copySelection, copySelection);
    }//GEN-LAST:event_copyTextActionPerformed

    
    private void textAreaColorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textAreaColorActionPerformed
        JFrame colorFrame = new JFrame();
        colorFrame.setBounds(0, 0, 700, 500);
        colorFrame.setTitle("BackgroundColor");
        colorFrame.setResizable(false);
        colorFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Color backgroundColor = JColorChooser.showDialog(this, "BackgroundColor", Color.white);
        textAreaColor.setBackground(backgroundColor);
        textArea.setBackground(backgroundColor);

    }//GEN-LAST:event_textAreaColorActionPerformed

    private void fontColorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fontColorActionPerformed
        JFrame colorFrame = new JFrame();
        colorFrame.setBounds(0, 0, 700, 500);
        colorFrame.setTitle("FontColor");
        colorFrame.setResizable(false);
        colorFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Color fontcolor = JColorChooser.showDialog(this, "BackgroundColor", Color.black);
        fontColor.setBackground(fontcolor);
        textArea.setForeground(fontcolor);
        
    }//GEN-LAST:event_fontColorActionPerformed

    private void fontsListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fontsListActionPerformed
        
        JComboBox cb = (JComboBox)evt.getSource();
        String fontName = (String)cb.getSelectedItem();
        //updateLabel(fontName);
        
        //String fontName = (String) fontsList.getSelectedItem();
        //System.out.println(fontName);
        if(fontName!=null)
        {
            GraphicsEnvironment graphEnviron = 
            GraphicsEnvironment.getLocalGraphicsEnvironment();
            Font[] allFonts = graphEnviron.getAllFonts();
            for(int i=0; i<allFonts.length; i++)
            {
                if(fontName.equals(allFonts[i].getFontName()))
                {
                    Font newFont = new Font(allFonts[i].getFontName(), Font.PLAIN, (int)sizeUpDown.getValue());
                    textArea.setFont( newFont );
                }

            }
        }
    }//GEN-LAST:event_fontsListActionPerformed

    private void sizeUpDownStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sizeUpDownStateChanged
        
        Font newFont = new Font(textArea.getFont().getFontName(), Font.PLAIN, (int)sizeUpDown.getValue());
        textArea.setFont( newFont );
    }//GEN-LAST:event_sizeUpDownStateChanged

    private void boldTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boldTextActionPerformed
        
        Font f=null;
        if(boldText.isSelected())
        {
            f = textArea.getFont();
            Font newFont = new Font(textArea.getFont().getFontName(), Font.BOLD, (int)sizeUpDown.getValue());
            textArea.setFont( newFont );
        }
        else
        {
            textArea.setFont( f );
        }
    }//GEN-LAST:event_boldTextActionPerformed

    private void italicTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_italicTextActionPerformed
        Font ff=null;
        if(italicText.isSelected())
        {
            ff = textArea.getFont();
            Font newFont = new Font(textArea.getFont().getFontName(), Font.ITALIC, (int)sizeUpDown.getValue());
            textArea.setFont( newFont );
        }
        else
        {
            textArea.setFont( ff );
        }
    }//GEN-LAST:event_italicTextActionPerformed

    private void textAreaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textAreaKeyTyped
        int words = countWords(textArea.getText());
        String text =Integer.toString(words);
        wordsCount.setText(text);
        
        int chars;
        chars = textArea.getText().length();
        String charsText = Integer.toString(chars);
        charCount.setText(charsText);
    }//GEN-LAST:event_textAreaKeyTyped
    
    public static int countWords(String str){
        if(str == null || str.isEmpty())
            return 0;

        int count = 0;
        for(int e = 0; e < str.length(); e++){
            if(str.charAt(e) != ' '){
                count++;
                while(str.charAt(e) != ' ' && e < str.length()-1){
                    e++;
                }
            }
        }
        return count;
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NotepadGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NotepadGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NotepadGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NotepadGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(NotepadGUI.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InstantiationException ex) {
                    Logger.getLogger(NotepadGUI.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IllegalAccessException ex) {
                    Logger.getLogger(NotepadGUI.class.getName()).log(Level.SEVERE, null, ex);
                } catch (UnsupportedLookAndFeelException ex) {
                    Logger.getLogger(NotepadGUI.class.getName()).log(Level.SEVERE, null, ex);
                }
                new NotepadGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem backStep;
    private javax.swing.JToggleButton boldText;
    private javax.swing.JLabel charCount;
    private javax.swing.JLabel charCountLabel;
    private javax.swing.JMenuItem copyText;
    private javax.swing.JMenuItem cutText;
    private javax.swing.JLabel dateLabel;
    private javax.swing.JMenu editMenu;
    private javax.swing.JMenuItem exitProgram;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JButton fontColor;
    private javax.swing.JComboBox<String> fontsList;
    private javax.swing.JToggleButton italicText;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JMenuItem newFile;
    private javax.swing.JMenuItem openFile;
    private javax.swing.JMenuItem pasteText;
    private javax.swing.JMenuItem printFile;
    private javax.swing.JMenuItem saveFile;
    private javax.swing.JMenuItem saveFileAs;
    private javax.swing.JTextField searchField;
    private javax.swing.JButton searchText;
    private javax.swing.JSpinner sizeUpDown;
    private javax.swing.JTextArea textArea;
    private javax.swing.JButton textAreaColor;
    private javax.swing.JLabel wordsCount;
    private javax.swing.JLabel wordsLabel;
    // End of variables declaration//GEN-END:variables
}
