package lab10;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import static java.awt.PageAttributes.MediaType.C;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.UIManager;

public class Notatnik extends JFrame implements ActionListener  {

    private JTextArea textArea;
    public Notatnik() {

        setTitle("Notatnik");

        Toolkit zestaw = Toolkit.getDefaultToolkit();
        Dimension rozmiarEkranu = zestaw.getScreenSize();
        int szerEkranu = rozmiarEkranu.width;
        int wysEkranu = rozmiarEkranu.height;
        setBounds(szerEkranu / 4, wysEkranu / 4, szerEkranu / 2, wysEkranu / 2);

        setResizable(false);

        JMenuBar pasekMenu = new JMenuBar();

        JMenu mPlik = new JMenu("Plik");
        JMenuItem otworz = new JMenuItem("Otworz");
        otworz.setAccelerator(KeyStroke.getKeyStroke("ctrl O"));
        JMenuItem zapisz = new JMenuItem("Zapisz");
        zapisz.setAccelerator(KeyStroke.getKeyStroke("ctrl Z"));
        JMenuItem zakoncz = new JMenuItem("Zakoncz");
        mPlik.add(otworz);
        mPlik.add(zapisz);
        mPlik.addSeparator();
        mPlik.add(zakoncz);
        mPlik.setMnemonic('P');
        mPlik.setToolTipText("Plik.");
        
        JMenu mEdycja = new JMenu("Edycja");
        JRadioButtonMenuItem powieksz = new JRadioButtonMenuItem("Powiększ czcionkę");
        JRadioButtonMenuItem pomniejsz = new JRadioButtonMenuItem("Pomniejsz czcionkę", true);
        mEdycja.add(powieksz);
        mEdycja.add(pomniejsz);
        ButtonGroup bg = new ButtonGroup();
        bg.add(powieksz);
        bg.add(pomniejsz);
        mEdycja.setMnemonic('E');
        mEdycja.setToolTipText("Edycja pliku.");
        

        JMenu mPomoc = new JMenu("Pomoc");

        pasekMenu.add(mPlik);
        pasekMenu.add(mEdycja);
        pasekMenu.add(mPomoc);
        mPomoc.setToolTipText("Pomoc.");
        
        setJMenuBar(pasekMenu);
        
        textArea = new JTextArea();
        JScrollPane sp = new JScrollPane(textArea,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        setLayout(new BorderLayout());
        add(sp,BorderLayout.CENTER);
        
        JPanel panelLewy = new JPanel(new FlowLayout(FlowLayout.CENTER));
	JPanel panelPrawy = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        JPanel panelPrzyciski = new JPanel(new GridLayout(1,2));
        panelPrzyciski.add(panelLewy);
	panelPrzyciski.add(panelPrawy);	
        add(panelPrzyciski,BorderLayout.SOUTH);
        
        JButton tytul = new JButton("tytuł");
	JButton podpis = new JButton("podpis");
	panelLewy.add(tytul);
	panelLewy.add(podpis);	
        
        JRadioButton bi = new JRadioButton("biały",true);
	JRadioButton zo = new JRadioButton("żółty");
	JRadioButton zi = new JRadioButton("różowy");

	ButtonGroup bg1 = new ButtonGroup();
        
	bg1.add(bi);
	bg1.add(zo);
	bg1.add(zi);
        
	panelPrawy.add(bi);
	panelPrawy.add(zo);
	panelPrawy.add(zi);
        
        bi.setActionCommand("51");
	zo.setActionCommand("52");
	zi.setActionCommand("53");
        
        bi.addActionListener(this);
	zo.addActionListener(this);
	zi.addActionListener(this);
        
        
        
    }

    public static void main(String[] args) throws Exception {
        //try{
        //UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
        //UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
        UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        //UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        Notatnik nt = new Notatnik();
        nt.setVisible(true);
        ImageIcon img = new ImageIcon("indeks.jpg");
        nt.setIconImage(img.getImage());
        nt.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //}
        //catch()
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        switch (Integer.parseInt(e.getActionCommand()))
		{
			case 11:
			{
				break;
			}
			case 12:
			{
				break;
			}
			case 13:
			{
				break;
			}
			case 21:
			{
				break;
			}
			case 22:
			{
				break;
			}
			case 23:
			{
				break;
			}
			case 31:
			{
				break;
			}
			case 41:
			{
				break;
			}		
			case 42:
			{
				break;
			}			
			case 51:
			{
				textArea.setBackground(Color.WHITE);
				break;
			}
			case 52:
			{
				textArea.setBackground(Color.YELLOW);
				break;
			}
			case 53:
			{
				textArea.setBackground(Color.pink);
				break;
			}
		}
        
    }
}
